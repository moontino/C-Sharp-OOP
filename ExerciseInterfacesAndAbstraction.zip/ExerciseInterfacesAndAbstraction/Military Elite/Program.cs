﻿
using MilitaryElite.Core;
using System;

namespace MilitaryElite
{
    public class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
