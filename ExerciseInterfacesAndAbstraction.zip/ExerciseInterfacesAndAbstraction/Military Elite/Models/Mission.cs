﻿using MilitaryElite.EnumCount;
using MilitaryElite.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite.Models
{
    public class Mission : IMissions
    {
        private const string InvalidState = "Invalid State";
        private const string ComplitedMission = "Mission already comlited!";
        public Mission(string codeName, string state)
        {
            CodeName = codeName;
            State = TryParseState(state);
        }

        public string CodeName { get; private set; }

        public State State { get; private set; }

        public void ComleteMission()
        {
            if (this.State==State.Finished)
            {
                throw new Exception(ComplitedMission);
            }
            State = State.Finished;
        }
        private State TryParseState(string stateStr)
        {
            State state;
            bool passed = Enum.TryParse<State>(stateStr, out state);
            if (!passed)
            {
                throw new Exception(InvalidState);
            }
            return state;
        }
        public override string ToString()
        {
            return $"Code Name: {this.CodeName} State: {State.ToString()}";
        }
    }
}
