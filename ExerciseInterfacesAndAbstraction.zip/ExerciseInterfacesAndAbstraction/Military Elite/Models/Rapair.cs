﻿using MilitaryElite.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite.Models
{
    public class Rapair : IRepair
    {
        public Rapair(string partTime, int hoursWorked)
        {
            this.PartTime = partTime;
            this.HoursWorked = hoursWorked;
        }

        public string PartTime { get; private set; }

        public int HoursWorked { get; private set; }
        public override string ToString()
        {
            return $"Part Name: {this.PartTime} Hours Worked: {this.HoursWorked}";
        }
    }
}
