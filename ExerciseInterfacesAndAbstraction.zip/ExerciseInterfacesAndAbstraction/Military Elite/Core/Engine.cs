﻿using MilitaryElite.Interfaces;
using MilitaryElite.Models;
using System;
using System.Collections.Generic;
using System.Linq;


namespace MilitaryElite.Core
{
    public class Engine
    {
        
        private readonly ICollection<ISoldier> soldiers;
        public Engine()
        {
            soldiers = new List<ISoldier>();
        }
        public void Run()
        {
            string tokens;
            while ((tokens=Console.ReadLine())!="End")
            {
                string[] tokensArg = tokens
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();

                ISoldier soldier = null;

                string typeSoldier = tokensArg[0];
                int id = int.Parse(tokensArg[1]);
                string firstName = tokensArg[2];
                string lastName = tokensArg[3];

                if (typeSoldier=="Private")
                {
                    soldier = AddPrivate(tokensArg, id, firstName, lastName);

                }
                else if (typeSoldier== "LieutenantGeneral")
                {
                    decimal salary = decimal.Parse(tokensArg[4]);
                    soldier = CreateGeneral(tokensArg, id, firstName, lastName, salary);
                }
                else if (typeSoldier== "Engineer")
                {
                    decimal salary = decimal.Parse(tokensArg[4]);
                    string corps = tokensArg[5];
                    try
                    {
                        IEngineer engineer = CreateEngineer(tokensArg, id, firstName, lastName, salary, corps);
                        soldier = engineer;
                    }
                    catch (Exception )
                    {

                        continue;
                    }
                }
                else if (typeSoldier== "Commando")
                {
                    decimal salary = decimal.Parse(tokensArg[4]);
                    string corps = tokensArg[5];

                    try
                    {
                        ICommando commando = CreateCommando(tokensArg, id, firstName, lastName, salary, corps);
                        soldier = commando;
                    }
                    catch (Exception)
                    {

                        continue;
                    }
                    
                }
                else if (typeSoldier=="Spy")
                {
                    soldier = CreateSpy(tokensArg, id, firstName, lastName);
                }
                if (soldier!=null)
                {
                    soldiers.Add(soldier);
                }
            }
            foreach (var soldier in this.soldiers)
            {
                Console.WriteLine(soldier);
            }
        }

        private static ISoldier CreateSpy(string[] tokensArg, int id, string firstName, string lastName)
        {
            ISoldier soldier;
            int codeNumber = int.Parse(tokensArg[4]);
            ISpy spy = new Spy(id, firstName, lastName, codeNumber);
            soldier = spy;
            return soldier;
        }

        private static Commando CreateCommando(string[] tokensArg, int id, string firstName, string lastName, decimal salary, string corps)
        {
            Commando commando = new Commando(id, firstName, lastName, salary, corps);
            string[] repairArg = tokensArg.Skip(6).ToArray();

            for (int i = 0; i < repairArg.Length; i += 2)
            {
                try
                {
                    string codeName = repairArg[i];
                    string state = repairArg[i + 1];
                    IMissions missions = new Mission(codeName, state);
                    commando.AddMission(missions);
                }
                catch (Exception)
                {

                    continue;
                }
            }

            return commando;
        }

        private static ISoldier AddPrivate(string[] tokensArg, int id, string firstName, string lastName)
        {
            ISoldier soldier;
            decimal salary = decimal.Parse(tokensArg[4]);
            soldier = new Private(id, firstName, lastName, salary);
            return soldier;
        }

        private ISoldier CreateGeneral(string[] tokensArg, int id, string firstName, string lastName, decimal salary)
        {
            ISoldier soldier;
            LieutenantGeneral general = new LieutenantGeneral(id, firstName, lastName, salary);
            foreach (var soldierId in tokensArg.Skip(5))
            {
                ISoldier privateToAdd = soldiers.First(s => s.Id == int.Parse(soldierId));
                general.AddPrivates(privateToAdd);
            }
            soldier = general;
            return soldier;
        }

        private static Engineer CreateEngineer(string[] tokensArg, int id, string firstName, string lastName, decimal salary, string corps)
        {
            Engineer engineer = new Engineer(id, firstName, lastName, salary, corps);
            string[] repairArg = tokensArg.Skip(6).ToArray();
            for (int i = 0; i < repairArg.Length; i += 2)
            {
                string part = repairArg[i];
                int hour = int.Parse(repairArg[i + 1]);
                IRepair repair = new Rapair(part, hour);
                engineer.AddRepairs(repair);
            }

            return engineer;
        }
    }
}
