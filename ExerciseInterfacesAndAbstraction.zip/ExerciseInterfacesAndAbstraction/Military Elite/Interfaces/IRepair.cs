﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite.Interfaces
{
   public interface IRepair
    {
        string PartTime { get; }
        int HoursWorked { get; }
    }
}
