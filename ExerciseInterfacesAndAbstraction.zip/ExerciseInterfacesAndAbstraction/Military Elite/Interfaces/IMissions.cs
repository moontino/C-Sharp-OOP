﻿
using MilitaryElite.EnumCount;

namespace MilitaryElite.Interfaces
{
   public  interface IMissions
    {
        string CodeName { get; }
        State State { get; }
        void ComleteMission();
    }
}
