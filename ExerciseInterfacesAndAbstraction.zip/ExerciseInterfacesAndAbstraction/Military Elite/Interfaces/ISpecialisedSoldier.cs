﻿using MilitaryElite.EnumCount;
namespace MilitaryElite.Interfaces
{
    public interface ISpecialisedSoldier:IPrivate
    {
        Corps Corps { get; }

    }
}
