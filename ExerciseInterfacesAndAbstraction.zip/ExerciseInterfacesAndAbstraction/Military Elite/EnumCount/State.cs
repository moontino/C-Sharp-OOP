﻿using System;
namespace MilitaryElite.EnumCount
{
    public enum State
    {
        inProgress=1,
        Finished = 2
    }
}
