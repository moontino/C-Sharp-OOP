﻿using BirthdayCelebrations.Core;
using System;

namespace BirthdayCelebrations
{
   public  class Program
    {
        static void Main(string[] args)
        {
            EngineForFood engine = new EngineForFood();
            engine.Run();
        }
    }
}
