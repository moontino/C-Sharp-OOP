﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthdayCelebrations.Interfaces
{
    interface IRebellious
    {
         string Name { get;}
         int Age { get; }
         string Group { get;}
    }
}
