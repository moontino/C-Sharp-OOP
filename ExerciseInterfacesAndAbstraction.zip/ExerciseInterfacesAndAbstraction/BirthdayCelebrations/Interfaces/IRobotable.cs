﻿
namespace BirthdayCelebrations.Interfaces
{
  
    public interface IRobotable
    {
        public string Model { get; }
        public string Id { get;  }
    }
}
