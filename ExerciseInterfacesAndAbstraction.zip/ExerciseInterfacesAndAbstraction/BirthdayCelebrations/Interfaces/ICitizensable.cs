﻿
namespace BirthdayCelebrations.Interfaces
{
    
    public interface ICitizensable
    {
        public string Name { get; }
        public int Age { get; }
        public string Id { get;  }
        public string Birthdate { get; }
    }
}
