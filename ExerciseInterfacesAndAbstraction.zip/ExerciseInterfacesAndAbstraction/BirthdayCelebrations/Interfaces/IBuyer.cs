﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthdayCelebrations.Interfaces
{
    interface IBuyer
    {
        public int Food { get;}
        void BuyFood();
    }
}
