﻿using BirthdayCelebrations.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BirthdayCelebrations.Core
{
    public class Engine
    {
        private List<string> years;
        public Engine()
        {
            years = new List<string>();
        }
        public void Run()
        {
            string arg;
            while ((arg = Console.ReadLine()) != "End")
            {
                string[] input = arg
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();

                string type = input[0];
                string name = input[1];

                if (input.Length == 5 && type == "Citizen")
                {
                    EnterCitizen(input, name);
                }
                else if (input.Length == 3 && type == "Pet")
                {
                    EnterPet(input, name);

                }
                else if (input.Length == 2 && type == "Robot")
                {
                    EnterRobot(input, name);
                }
            }
            string year = Console.ReadLine();
            OutPut(year);

        }

        private static void EnterRobot(string[] input, string name)
        {
            string id = input[2];
            Robot robot = new Robot(name, id);
        }

        private void EnterPet(string[] input, string name)
        {
            string birthdate = input[2];
            Pet pet = new Pet(name, birthdate);
            years.Add(birthdate);
        }

        private void EnterCitizen(string[] input, string name)
        {
            int age = int.Parse(input[2]);
            string id = input[3];
            string birthdate = input[4];
            Citizen citizen = new Citizen(name, age, id, birthdate);
            years.Add(birthdate);
        }

        private void OutPut(string year)
        {

            int count = 0;
            foreach (var age in years)
            {
                var substringYear = age.Substring(age.Length - year.Length, year.Length);
                if (substringYear == year)
                {
                    count++;
                    Console.WriteLine(age);
                }
            }
            

        }
    }
}


