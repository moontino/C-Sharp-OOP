﻿using BirthdayCelebrations.Models;
using System.Collections.Generic;
using System;
using System.Linq;

namespace BirthdayCelebrations.Core
{
    public class EngineForFood
    {
        private List<Rabel> rabels;
        private List<Citizen> citizens;
        public EngineForFood()
        {
            this.rabels = new List<Rabel>();
            this.citizens = new List<Citizen>();
        }
        public void Run()
        {
            int n = int.Parse(Console.ReadLine());
            EnterInput(n);
            int food = 0;
            string names;
            names = FoodAmount(ref food);
        }

        private string FoodAmount(ref int food)
        {
            string names;
            while ((names = Console.ReadLine()) != "End")
            {
                Rabel rabel = rabels.FirstOrDefault(r => r.Name == names);
                Citizen citizen = citizens.FirstOrDefault(c => c.Name == names);
                if (rabel != null)
                {
                    rabel.BuyFood();
                    food += 5;
                }
                else if (citizen != null)
                {
                    citizen.BuyFood();
                    food += 10;
                }
            }
            Console.WriteLine(food);
            return names;
        }

        private void EnterInput(int n)
        {
            for (int i = 0; i < n; i++)
            {
                string[] personArg = Console.ReadLine()
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();

                string name = personArg[0];
                int age = int.Parse(personArg[1]);

                if (personArg.Length == 4)
                {
                    EnterCitizen(personArg, name, age);
                }
                else if (personArg.Length == 3)
                {
                    EnterRabel(personArg, name, age);
                }
            }
        }

        private void EnterRabel(string[] personArg, string name, int age)
        {
            string group = personArg[2];
            Rabel rabel = new Rabel(name, age, group);
            rabels.Add(rabel);
        }

        private void EnterCitizen(string[] personArg, string name, int age)
        {
            string id = personArg[2];
            string birthday = personArg[3];
            Citizen citizen = new Citizen(name, age, id, birthday);
            citizens.Add(citizen);
        }
    }
}
