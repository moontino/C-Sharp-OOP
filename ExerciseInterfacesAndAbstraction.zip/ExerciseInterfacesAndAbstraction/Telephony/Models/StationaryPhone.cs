﻿

using Telephony.Interfaces;

namespace Telephony.Models
{
    public class StationaryPhone : ICallingable
    {
        public string Calling(string numbers)
        {
            return $"Dialing... {numbers}";
        }
    }
}
