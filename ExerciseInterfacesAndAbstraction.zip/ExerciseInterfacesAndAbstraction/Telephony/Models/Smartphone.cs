﻿using System;
using System.Collections.Generic;
using System.Text;
using Telephony.Interfaces;

namespace Telephony.Models
{
    public class Smartphone : IBrowseable, ICallingable
    {

        public string Calling(string numbers)
        {
            return $"Calling... {numbers}";
        }

        public string Searching(string web)
        {
            return $"Browsing: {web}!";
        }
    }
}
