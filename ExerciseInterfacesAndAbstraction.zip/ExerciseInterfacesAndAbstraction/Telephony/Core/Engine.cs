﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Telephony.Models;

namespace Telephony.Core
{
    public class Engine
    {
       
        public void Run()
        {
            string[] phoneNumbers = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                .ToArray(); 
            string[] url = Console.ReadLine()
                 .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                 .ToArray();
            
            for (int i = 0; i < phoneNumbers.Length; i++)
            {
                try
                {
                    CallingPhones(phoneNumbers, i);
                }
                catch (InvalidOperationException ex )
                {

                    Console.WriteLine(ex.Message);
                }  
            }
            for (int i = 0; i < url.Length; i++)
            {
                try
                {
                    SearchingWep(url, i);
                }
                catch (InvalidOperationException ex)
                {

                    Console.WriteLine(ex.Message);
                }
               
            }
        }

        private static void SearchingWep(string[] url, int i)
        {
            var curUrl = url[i];
            bool isHaveDigits = curUrl.Any(char.IsDigit);
            if (!isHaveDigits)
            {
                Smartphone smartphone = new Smartphone();
                Console.WriteLine(smartphone.Searching(curUrl)); 
            }
            else
            {
                throw new InvalidOperationException(Exception.InvalidUrl);
            }
        }

        private static void CallingPhones(string[] phoneNumbers, int i)
        {
            var curPhoneNumber = phoneNumbers[i];
            bool isDigitsOnly = curPhoneNumber.All(char.IsDigit);
            string TypeOfPhone = curPhoneNumber.Length == 10 ? "Smartphone" : "Stationary";
            if (isDigitsOnly && TypeOfPhone == "Smartphone")
            {
                Smartphone smartphone = new Smartphone();
                Console.WriteLine(smartphone.Calling(curPhoneNumber));
            }
            else if (isDigitsOnly && TypeOfPhone == "Stationary"&&curPhoneNumber.Length==7)
            {
                StationaryPhone stationaryPhone = new StationaryPhone();
                Console.WriteLine(stationaryPhone.Calling(curPhoneNumber)); 
            }
            else if (!isDigitsOnly)
            {
                throw new InvalidOperationException(Exception.InvalidNumber);
            }
        }
    }
}
