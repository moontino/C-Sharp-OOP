﻿

namespace Telephony.Interfaces
{
    interface ICallingable
    {
        string Calling(string numbers);
    }
}
