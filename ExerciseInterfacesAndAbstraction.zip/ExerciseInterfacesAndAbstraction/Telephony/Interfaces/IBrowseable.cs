﻿

namespace Telephony.Interfaces
{
    interface IBrowseable
    {
        string Searching(string web);
    }
}
