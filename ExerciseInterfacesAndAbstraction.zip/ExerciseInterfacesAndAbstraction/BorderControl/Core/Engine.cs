﻿using BorderControl.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BorderControl.Core
{
    public class Engine
    {
        private List<string> ids;
        public Engine()
        {
            ids = new List<string>();
        }
        public void Run()
        {
            string arg;
            while ((arg = Console.ReadLine()) != "End")
            {
                string[] input = arg
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();

                if (input.Length == 3)
                {
                    EnterCitizen(input);
                }
                else if (input.Length == 2)
                {
                    EnterRobot(input);
                }
            }
            string fakeIds = Console.ReadLine();
            FakeIds(fakeIds);
        }

        private void FakeIds(string fakeIds)
        {
            foreach (var id in ids)
            {
                var substringIdEnd = id.Substring(id.Length - fakeIds.Length, fakeIds.Length);
                if (substringIdEnd == fakeIds)
                {
                    Console.WriteLine(id);
                }
            }
        }

        private void EnterRobot(string[] input)
        {
            string model = input[0];
            string id = input[1];
            Robot robot = new Robot(model, id);
            ids.Add(id);
        }

        private void EnterCitizen(string[] input)
        {
            string name = input[0];
            int age = int.Parse(input[1]);
            string id = input[2];
            Citizen citizen = new Citizen(name, age, id);
            ids.Add(id);
        }
    }
}
