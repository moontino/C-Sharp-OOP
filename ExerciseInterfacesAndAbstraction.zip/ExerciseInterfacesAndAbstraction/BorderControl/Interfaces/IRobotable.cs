﻿
namespace BorderControl.Interfaces
{
  
    public interface IRobotable
    {
        public string Model { get; }
        public string Id { get;  }
    }
}
