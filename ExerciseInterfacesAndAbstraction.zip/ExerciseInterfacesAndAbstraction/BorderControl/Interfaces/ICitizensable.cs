﻿
namespace BorderControl.Interfaces
{
    
    public interface ICitizensable
    {
        public string Name { get; }
        public int Age { get; }
        public string Id { get;  }
    }
}
