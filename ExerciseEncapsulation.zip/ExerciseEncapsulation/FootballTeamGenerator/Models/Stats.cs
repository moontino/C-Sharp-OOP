﻿using System;
using FootballTeamGenerator.ErrorMessages;
namespace FootballTeamGenerator.Models
{
    public class Stats
    {
        private const int MIN_STAT = 0;
        private const int MAX_STAT = 100;
        private const double COUNT_OF_SKILS = 5.0;

        private int endurance;
        private int sprint;
        private int dribble;
        private int passing;
        private int shooting;

        public Stats(int endurance, int sprint, int dribble, int passing, int shooting)
        {
            this.Endurance = endurance;
            this.Sprint = sprint;
            this.Dribble = dribble;
            this.Passing = passing;
            this.Shooting = shooting;
        }

        public int Endurance
        {
            get { return this.endurance; }
            private set
            {
                InvalidStats(value, nameof(this.Endurance));
                this.endurance = value;
            }
        }
        public int Sprint
        {
            get { return this.sprint; }
            private set
            {
                InvalidStats(value, nameof(this.Sprint));
                this.sprint = value;
            }
        }
        public int Dribble
        {
            get { return this.dribble; }
            private set
            {
                InvalidStats(value, nameof(this.Dribble));
                this.dribble = value;
            }
        }
        public int Passing
        {
            get { return this.passing; }
            private set
            {
                InvalidStats(value, nameof(this.Passing));
                this.passing = value;
            }
        }
        public int Shooting
        {
            get { return this.shooting; }
            private set
            {
                InvalidStats(value, nameof(this.Shooting));
                this.shooting = value;
            }
        }
        public double AvaragePlayerSkill =>
            (this.Endurance +
            this.Sprint +
            this.Dribble +
            this.Passing +
            this.Shooting )/ COUNT_OF_SKILS;
        private void InvalidStats(int value,string name)
        {
            if (value<MIN_STAT||value>MAX_STAT)
            {
                throw new Exception(String.Format(ExceptionMessages.InvalidRangeOfStat, name, MIN_STAT, MAX_STAT));
            }
        }
    }
}
