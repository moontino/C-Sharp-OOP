﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using FootballTeamGenerator.ErrorMessages;
namespace FootballTeamGenerator.Models
{
    public class Engine
    {
        private readonly List<Team> teams;
        public Engine()
        {
            teams = new List<Team>();
        }
      
        public void Run()
        {
            string command = Console.ReadLine();
            while (command!="END")
            {
                try
                {
                    string[] cmdTokens = command.Split(";").ToArray();
                    string curCommand = cmdTokens[0];
                    string teamName = cmdTokens[1];

                    if (curCommand=="Team")
                    {
                        AddTeam(teamName);
                    }
                    else if (curCommand=="Add")
                    {
                        AddPlayer(cmdTokens, teamName);

                    }
                    else if (curCommand=="Remove")
                    {
                        RemovePlayer(cmdTokens, teamName);
                    }
                    else if (curCommand=="Rating")
                    {
                        RatingTeam(teamName);
                    }
                }
                catch (Exception ex )
                {

                    Console.WriteLine(ex.Message);
                }
                command = Console.ReadLine();
            }
        }

        private void RatingTeam(string teamName)
        {
            ValidateTeam(teamName);
            Team team = teams.First(t => t.Name == teamName);
            Console.WriteLine(team);
        }

        private void RemovePlayer(string[] cmdTokens, string teamName)
        {
            ValidateTeam(teamName);
            string playerName = cmdTokens[2];
            Team team = teams.First(t => t.Name == teamName);
            team.RemovePlayer(playerName);
        }

        private void AddPlayer(string[] cmdTokens, string teamName)
        {
            ValidateTeam(teamName);
            string playerName = cmdTokens[2];
            Stats stats = InputStats(cmdTokens);
            Player player = new Player(playerName, stats);
            Team team = this.teams.First(t => t.Name == teamName);
            team.AddPlayer(player);
        }

        private void AddTeam(string teamName)
        {
            Team team = new Team(teamName);
            teams.Add(team);
        }

        private Stats InputStats(string[] cmdTokens)
        {
            int endurance = int.Parse(cmdTokens[3]);
            int sprint = int.Parse(cmdTokens[4]);
            int dribble = int.Parse(cmdTokens[5]);
            int passing = int.Parse(cmdTokens[6]);
            int shooting = int.Parse(cmdTokens[7]);
            Stats stats = new Stats(endurance, sprint, dribble, passing, shooting);
            return stats;
        }

        private void ValidateTeam(string teamName)
        {
            Team team = teams.FirstOrDefault(t => t.Name == teamName);
            if (team==null)
            {
                throw new Exception(String.Format(ExceptionMessages.MissingTeam,teamName));
            }
        }
    }
}
