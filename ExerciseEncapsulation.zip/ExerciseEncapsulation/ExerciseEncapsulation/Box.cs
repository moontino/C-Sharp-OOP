﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassBoxData
{
    public class Box
    {
        private const string INVALID_MESS = "cannot be zero or negative.";
        private double l = 0;
        private double w = 0;
        private double h = 0;
        private double length;
        private double width;
        private double height;

        public Box(double lenght, double width, double height)
        {
            Lenght = lenght;
            Width = width;
            Height = height;
        }

        public double Lenght
        {
            get { return this.length; }
            private set
            {
                if (value <= 0)
                {
                    throw new InvalidOperationException($"Length {INVALID_MESS}");
                }
                this.length = value;
            }
        }
        public double Width
        {
            get { return this.width; }
            private set
            {
                if (value <= 0)
                {
                    throw new InvalidOperationException($"Width {INVALID_MESS}");
                }
                this.width = value;
            }
        }
        public double Height
        {
            get { return this.height; }
            private set
            {
                if (value <= 0)
                {
                    throw new InvalidOperationException($"Height {INVALID_MESS}");
                }
                this.height = value;
            }
        }
        public double SurfaceArea(Box box)
        {
            l = box.length;
            w = box.width;
            h = box.height;
            return (2 * l * w) + (2 * l * h) + (2 * w * h);
        }
        public double LateralSurfaceArea(Box box)
        {

            return (2 * l * h) + (2 * w * h);
        }
        public double Volume(Box box)
        {
            return l * w * h;
        }
        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.AppendLine($"Surface Area - {SurfaceArea(this):F2}")
            .AppendLine($"Lateral Surface Area - {LateralSurfaceArea(this):F2}")
            .AppendLine($"Volume - {Volume(this):F2}");
            return sb.ToString().TrimEnd();
        }
    }
}
