﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingSpree.ErrorMess
{
    static public class ErrorMess
    {
        public static string ExceptionName = "Name cannot be empty";
        public static string ExceptionMoney = "Money cannot be negative";
        
    }
}
