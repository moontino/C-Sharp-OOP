﻿using System;
using System.Collections.Generic;
using System.Text;
using ShoppingSpree.ErrorMess;

namespace ShoppingSpree.Models
{
    public class Person
    {
        private string name;
        private decimal money;
        private List<Product> bag;
        private Person()
        {
            bag = new List<Product>(); 
        }
        public Person(string name, decimal money):this()
        {
            Name = name;
            Money = money;
            
        }
        public IReadOnlyCollection<Product> Bag
       => this.bag.AsReadOnly();
        public string Name
        {
            get { return this.name; }
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new Exception(ErrorMess.ErrorMess.ExceptionName);
                }
                this.name = value;
            }
        }
        public decimal Money
        {
            get { return this.money; }
            private set
            {
                if (value<0)
                {
                    throw new Exception(ErrorMess.ErrorMess.ExceptionMoney);
                }
                this.money = value;
            }
        }
        public void BuyProduct(Product product)
        {
            if (this.Money<product.Cost)
            {
                throw new Exception($"{this.Name} can't afford {product.Name}");
            }
            else
            { 
                this.Money -= product.Cost;             
                bag.Add(product);                
            }
        }
        public override string ToString()
        {
            var curBagArg = this.bag.Count == 0 ? "Nothing bought" : string.Join(", ", this.bag);
            return $"{this.Name} - {curBagArg}";
        }
    }
}
