﻿using System;
using System.Collections.Generic;
using System.Text;
using ShoppingSpree.ErrorMess;

namespace ShoppingSpree.Models
{
    public class Product
    {
        private string name;
        private decimal cost;

        public Product(string name, decimal cost)
        {
            Name = name;
            Cost = cost;
        }

        public string Name
        {
            get { return this.name; }
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new Exception(ErrorMess.ErrorMess.ExceptionName);
                }
                this.name = value;
            }
        }
        public decimal Cost
        {
            get { return this.cost; }
            private set
            {
                if (value < 0)
                {
                    throw new Exception(ErrorMess.ErrorMess.ExceptionMoney);
                }
                this.cost = value;
            }

        }
        public override string ToString()
        {
            return $"{Name}";
        }
    }
}
