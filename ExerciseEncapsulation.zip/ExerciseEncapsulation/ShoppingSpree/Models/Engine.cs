﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShoppingSpree.Models
{
    public class Engine
    {
        private List<Person> people;
        private List<Product> products;
        public Engine()
        {
            this.people = new List<Person>();
            this.products = new List<Product>();
        }
        public void Run()
        {
            AddPeople();
            AddProducts();
            InputArg();
            PrintOutput();
        }

        private void PrintOutput()
        {
            foreach (Person person in people)
            {
                Console.WriteLine(person);
            }
        }

        private void InputArg()
        {
            string input;
            while ((input = Console.ReadLine()) != "END")
            {
                string[] curArg = input
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();
                string personName = curArg[0];
                string productName = curArg[1];
                try
                {
                    Person person = people.FirstOrDefault(n => n.Name == personName);
                    Product product = products.FirstOrDefault(n => n.Name == productName);
                    person.BuyProduct(product);
                    Console.WriteLine($"{person.Name} bought {product.Name}");
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.Message);
                }
            }
        }

        private void AddProducts()
        {
            string[] productsArg = Console.ReadLine()
                            .Split(";", StringSplitOptions.RemoveEmptyEntries)
                            .ToArray();
            for (int i = 0; i < productsArg.Length; i++)
            {
                string[] curProductArgs = productsArg[i]
                    .Split("=", StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();

                string productName = curProductArgs[0];
                decimal productPrice = decimal.Parse(curProductArgs[1]);

                Product product = new Product(productName, productPrice);
                products.Add(product);
            }
        }

        private void AddPeople()
        {
            string[] clients = Console.ReadLine()
                .Split(";", StringSplitOptions.RemoveEmptyEntries)
                .ToArray();
            for (int i = 0; i < clients.Length; i++)
            {
                string[] curPersonArgs = clients[i]
                    .Split("=", StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();

                string personName = curPersonArgs[0];
                decimal personMoney = decimal.Parse(curPersonArgs[1]);

                Person person = new Person(personName, personMoney);
                people.Add(person);
            }
        }
    }
}
