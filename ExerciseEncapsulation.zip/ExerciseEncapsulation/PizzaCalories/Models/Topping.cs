﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pizza.Models
{
    public class Topping
    {
        private const int CALORIES_PER_GRAM = 2;
        private const string INVALID_TOPPING_TYPE = "Cannot place {0} on top of your pizza.";
        private const string INVALID_WEIGHT = "{0} weight should be in the range [{1}..{2}].";
        private const int MIN_WEIGHT = 1;
        private const int MAX_WEIGHT = 50;

        private string typeOfTopping;
        private double weight;
        private readonly Dictionary<string, double> defaultTypeOfTopping = new Dictionary<string, double>()
        {
            {"meat",1.2},
            {"veggies",0.8},
            {"cheese",1.1},
            {"sauce",0.9}
        };

        public Topping(string typeOfTopping, double weight)
        {
            this.TypeOfTopping = typeOfTopping;
            this.Weight = weight;
        }
        private string TypeOfTopping
        {
            get { return this.typeOfTopping; }
            set
            {
                if (!defaultTypeOfTopping.ContainsKey(value.ToLower()))
                {
                    throw new Exception(String.Format(INVALID_TOPPING_TYPE, value));
                }
                this.typeOfTopping = value;
            }
        }
        public double Weight
        {
            get { return this.weight; }
            private set
            {
                if (value < MIN_WEIGHT || value > MAX_WEIGHT)
                {
                    throw new Exception(String.Format(INVALID_WEIGHT,
                        this.typeOfTopping,
                        MIN_WEIGHT,
                        MAX_WEIGHT));
                }
                this.weight = value;
            }
        }
        public double CaloriesPerGram =>
            CALORIES_PER_GRAM *
            defaultTypeOfTopping[TypeOfTopping.ToLower()];

    }
}
