﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pizza.Models
{
    public class Engine
    {
        public void Run()
        {
            string[] pizzaArg = Console.ReadLine().Split(" ");
            string[] doughArg = Console.ReadLine().Split(" ");
            Dough dough = new Dough(doughArg[1], doughArg[2], double.Parse(doughArg[3]));
            Pizza pizza = new Pizza(pizzaArg[1], dough);
            string input;
            while ((input=Console.ReadLine())!="END")
            {
                string[] toppingArg = input.Split(" ");
                Topping topping = new Topping(toppingArg[1], double.Parse(toppingArg[2]));
                pizza.AddToppings(topping);
            }
            Console.WriteLine($"{pizza.Name} - {pizza.TotalCalories:F2} Calories.");
        }
    }
}
