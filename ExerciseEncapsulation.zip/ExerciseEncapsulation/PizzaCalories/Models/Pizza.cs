﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pizza.Models
{
    public class Pizza
    {
		private const string INVALID_NUMBER_OF_TOPPINGS = "Number of toppings should be in range [{0}..{1}].";
		private const int MIN_COUNT_TOPPING = 0;
		private const int MAX_COUNT_TOPPING = 10;
		private const string INVALID_PIZZA = "Pizza name should be between {0} and {1} symbols.";
		private const int MIN_LENGHT = 1;
		private const int MAX_LENGHT = 15;
		private string name;
		private List<Topping> toppings;
		private Dough dough;

		private Pizza()
		{
			this.toppings = new List<Topping>();
		}
		public Pizza(string name, Dough dough):this()
		{
			this.Name = name;
			this.Dough = dough;
		}

		public string Name
		{
			get { return this.name; }
			private set {
				if (value ==null||value.Length<MIN_LENGHT||value.Length>MAX_LENGHT)
				{
					throw new Exception(String.Format(INVALID_PIZZA, MIN_LENGHT, MAX_LENGHT));
				}
				this.name = value; 
			}
		}		
		public Dough Dough
		{
			get { return this.dough; }
			set { this.dough = value; }
		}
		public IReadOnlyCollection<Topping> Toppings => this.toppings;//maybe
		public double TotalCalories => CalculatedCalories();
		public void AddToppings(Topping topping)
		{
			if (this.toppings.Count<MIN_COUNT_TOPPING||
				this.toppings.Count>MAX_COUNT_TOPPING)
			{
				throw new Exception(String.Format(INVALID_NUMBER_OF_TOPPINGS, MIN_COUNT_TOPPING, MAX_COUNT_TOPPING));
			}
			this.toppings.Add(topping);
		}
		private double CalculatedCalories()
		{
			double result = this.dough.CaloreisPerGram * this.dough.Weight;
			foreach (Topping topping in this.toppings)
			{
				result += topping.CaloriesPerGram * topping.Weight;
			}
			return result;
		}
	}
}
