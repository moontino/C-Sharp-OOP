﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pizza.Models
{
    public class Dough
    {
        private const int CALORIES_PER_GRAM = 2;
        private const string INVALID_TYPE = "Invalid type of dough.";
        private static string INVALID_WEIGHT = $"Dough weight should be in the range [{MIN_WEIGHT}..{MAX_WEIGHT}].";
        private const int MIN_WEIGHT = 1;
        private const int MAX_WEIGHT = 200;

        private readonly Dictionary<string, double> defaultFlourType = new Dictionary<string, double>()
        {
            {"white",1.5},
            {"wholegrain",1.0}
        };
        private readonly Dictionary<string, double> defaultBakingTechnique = new Dictionary<string, double>()
        {
            {"crispy",0.9},
            {"chewy",1.1},
            {"homemade",1.0}
        };

        private string flourType;
        private string bakingTechnique;
        private double weight;

        public Dough(string flourType, string bakingTechnique, double weight)
        {
            this.FlourType = flourType;
            this.BakingTechnique = bakingTechnique;
            this.Weight = weight;
        }

        private string FlourType
        {
            get
            { return this.flourType; }
            set
            {
                if (!defaultFlourType.ContainsKey(value.ToLower()))
                {
                    throw new Exception(INVALID_TYPE);
                }
                this.flourType = value;
            }
        }
        private string BakingTechnique
        {
            get { return this.bakingTechnique; }
            set
            {
                if (!defaultBakingTechnique.ContainsKey(value.ToLower()))
                {
                    throw new Exception(INVALID_TYPE);
                }
                this.bakingTechnique = value;
            }
        }
        public double Weight
        {
            get { return this.weight; }
            private set
            {
                if (value < MIN_WEIGHT || value > MAX_WEIGHT)
                {
                    throw new Exception(INVALID_WEIGHT);
                }
                this.weight = value;
            }
        }
        public double CaloreisPerGram =>
            CALORIES_PER_GRAM
           * defaultFlourType[this.FlourType.ToLower()]
            * defaultBakingTechnique[this.BakingTechnique.ToLower()];
    }
}
