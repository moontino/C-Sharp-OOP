﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NeedForSpeed
{
    public class Car : Vihicle
    {
        private const double DefaultFuelConsumption= 3;
        public Car(int horsePower, double fuel) : base(horsePower, fuel)
        {
        }
        public override double FuelConsumption => DefaultFuelConsumption;
        public override void Drive(double kilometers)
        {
            var curFuel = Fuel - kilometers * FuelConsumption;
            if (curFuel >= 0)
            {
                Fuel = curFuel;
            }
        }
    }
}
