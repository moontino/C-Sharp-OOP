﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Animals
{
    public abstract class Animal
    {
        private string name;
        private int age;
        private string gender;

        public Animal(string name, int age, string gender)
        {
            Name = name;
            Age = age;
            Gender = gender;
        }

        public string Name
        {
            get { return this.name; }

            protected set
            {
                if (!String.IsNullOrWhiteSpace(value))
                {
                    this.name = value;
                }
                else
                {
                    throw new InvalidOperationException("Invalid input!");
                }
            }
        }
        public int Age
        {
            get { return this.age; }
            protected set
            {
                if (value > -1)
                {
                    this.age = value;
                }
                else
                {
                    throw new InvalidOperationException("Invalid input!");
                }
            }
        }
        public string Gender
        {
            get { return this.gender; }
            protected set
            {
                if (value == "Male" || value == "Female")
                {
                    this.gender = value;
                }
                else
                {
                    throw new InvalidOperationException("Invalid input!");
                }
            }
        }

        public abstract string ProduceSound();
        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.AppendLine($"{this.GetType().Name}");
            sb.AppendLine($"{this.Name} {this.Age} {this.Gender}");
            sb.AppendLine($"{ProduceSound()}");
            return sb.ToString().TrimEnd();
        }
    }
}
