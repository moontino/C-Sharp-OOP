﻿namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            SoulMaster soulMaster = new SoulMaster("Ivan", 100);
            System.Console.WriteLine(soulMaster);
        }
    }
}